import 'dart:io';

class BankAccount {
  double _balance = 0.0;
  double get balance => _balance;
  List<String> _transactionHistory = [];

  void deposit(double amount) {
    if (amount <= 0) {
      print("Invalid Amount");
      return;
    }
    _balance += amount;
    _transactionHistory.add("Deposited: $amount");
    print("Deposited: $amount. Current Balance: $_balance");
  }

  void withdraw(double amount) {
    if (amount <= 0) {
      print("Invalid Withdraw");
      return;
    }
    if (amount > _balance) {
      print("Not Enough Balance");
      return;
    }
    _balance -= amount;
    _transactionHistory.add("Withdrew: $amount");
    print("Withdrew: $amount. Current Balance: $_balance");
  }

  void showTransactionHistory() {
    if (_transactionHistory.isEmpty) {
      print("No Transactions Yet");
      return;
    }
    print("Transaction History:");
    for (var transaction in _transactionHistory) {
      print(transaction);
    }
  }
}

class KidsAccount extends BankAccount {
  @override
  void withdraw(double amount) {
    if (amount > 100) {
      print("Withdraw Is Not Possible");
      return;
    }
    super.withdraw(amount);
  }
}

void main() {
  BankAccount? account;

  print("Welcome to the bank system!");
  print("Please choose the type of account:");
  print("1. Regular Account");
  print("2. Kids Account");

  String? accountType = stdin.readLineSync();
  if (accountType == '1') {
    account = BankAccount();
    print("Regular account created.");
  } else if (accountType == '2') {
    account = KidsAccount();
    print("Kids account created with withdrawal limit of 100.");
  } else {
    print("Invalid selection. Exiting...");
    return;
  }

  while (true) {
    print("\nChoose an operation:");
    print("1. Deposit");
    print("2. Withdraw");
    print("3. Show Transaction History");
    print("4. Exit");

    String? choice = stdin.readLineSync();
    if (choice == '1') {
      print("Enter amount to deposit:");
      double amount = double.parse(stdin.readLineSync()!);
      account.deposit(amount);
    } else if (choice == '2') {
      print("Enter amount to withdraw:");
      double amount = double.parse(stdin.readLineSync()!);
      account.withdraw(amount);
    } else if (choice == '3') {
      account.showTransactionHistory();
    } else if (choice == '4') {
      print("Exiting the system. Goodbye!");
      break;
    } else {
      print("Invalid choice, please try again.");
    }
  }
}
