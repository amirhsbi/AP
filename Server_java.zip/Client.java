import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        String address = "localhost";
        int port = 1239;

        try (Socket socket = new Socket(address, port);
             BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
             Scanner sc = new Scanner(System.in)) {

            String initialMessage = br.readLine();
            if (initialMessage != null) {
                System.out.println("Server: " + initialMessage);
            }

            System.out.print("Enter command (LOGIN or SIGNUP): ");
            String command = sc.nextLine();
            bw.write(command);
            bw.newLine();
            bw.flush();

            String response;
            while ((response = br.readLine()) != null) {
                System.out.println("Server: " + response);

                if (response.endsWith(":")) {
                    System.out.print("Enter input: ");
                    String userInput = sc.nextLine();
                    bw.write(userInput);
                    bw.newLine();
                    bw.flush();
                } else {
                    if (response.startsWith("Welcome") || response.startsWith("Invalid creds") || response.startsWith("User exists") || response.startsWith("Signup failed")) {
                        break;
                    }
                }
            }

            if (response != null && response.startsWith("Welcome")) {
                System.out.println("You are now logged in as " + response.substring(8, response.length() - 1));
            } else {
                System.out.println("Connection closed by server.");
                return;
            }

            while (true) {
                System.out.print("Enter command (math:<expr>, logout, listusers, serverdown): ");
                String userInput = sc.nextLine();

                bw.write(userInput);
                bw.newLine();
                bw.flush();

                String serverResponse = br.readLine();
                if (serverResponse != null) {
                    System.out.println("Server: " + serverResponse);
                } else {
                    System.out.println("Server closed the connection.");
                    break;
                }

                if (userInput.equalsIgnoreCase("logout") || userInput.equalsIgnoreCase("serverdown")) {
                    System.out.println("Exiting...");
                    break;
                }
            }

        } catch (IOException e) {
            System.err.println("Connection error: " + e.getMessage());
        }
    }
}
