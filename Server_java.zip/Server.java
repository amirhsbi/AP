import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class Server {
    private static Map<String, String> users = new HashMap<>(); // Store usernames and passwords
    private static boolean isRunning = true; // Control server running status
    private static String currentUser = null; // Track the current user

    public static void main(String[] args) {
        int port = 1239; // Define server port
        users.put("admin", "adminpass"); // Add default admin user

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server started on port " + port);

            while (isRunning) {
                Socket clientSocket = serverSocket.accept(); // Accept client connections
                System.out.println("Connected: " + clientSocket.getInetAddress().getHostAddress());

                // Create input and output streams for communication
                BufferedReader br = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));

                bw.write("Welcome! Type LOGIN or SIGNUP:");
                bw.newLine();
                bw.flush();

                String command = br.readLine();

                // Handle LOGIN or SIGNUP commands
                if (command.equalsIgnoreCase("LOGIN")) {
                    if (!login(br, bw)) {
                        clientSocket.close(); // Close the connection if login fails
                        continue;
                    }
                } else if (command.equalsIgnoreCase("SIGNUP")) {
                    if (!signup(br, bw)) {
                        clientSocket.close(); // Close the connection if signup fails
                        continue;
                    }
                } else {
                    bw.write("Invalid command. Bye.");
                    bw.newLine();
                    bw.flush();
                    clientSocket.close();
                    continue;
                }

                // Handle further commands after login/signup
                while (true) {
                    String msg = br.readLine();
                    if (msg == null)
                        break;

                    msg = msg.trim();

                    if (msg.equalsIgnoreCase("logout")) {
                        bw.write("Logged out.");
                        bw.newLine();
                        bw.flush();
                        currentUser = null;
                        break;
                    } else if (msg.equalsIgnoreCase("serverdown")) {
                        if (currentUser != null && currentUser.equals("admin")) {
                            bw.write("Shutting down.");
                            bw.newLine();
                            bw.flush();
                            isRunning = false;
                            break;
                        } else {
                            bw.write("Unauthorized command.");
                            bw.newLine();
                            bw.flush();
                        }
                    } else if (msg.equalsIgnoreCase("listusers")) {
                        if (currentUser != null && currentUser.equals("admin")) {
                            bw.write("Users:");
                            bw.newLine();
                            for (String user : users.keySet()) {
                                bw.write(user);
                                bw.newLine();
                            }
                            bw.flush();
                        } else {
                            bw.write("No access.");
                            bw.newLine();
                            bw.flush();
                        }
                    } else if (msg.startsWith("math:")) {
                        String expr = msg.substring(5).trim();
                        String result = calculate(expr);
                        bw.write(result);
                        bw.newLine();
                        bw.flush();
                    } else {
                        bw.write("Unknown command.");
                        bw.newLine();
                        bw.flush();
                    }
                }

                clientSocket.close();
                System.out.println("Disconnected: " + currentUser);

                if (!isRunning) {
                    System.out.println("Server shutting down...");
                }
            }

            System.out.println("Server stopped.");

        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }

    private static boolean login(BufferedReader br, BufferedWriter bw) throws IOException {
        bw.write("Username:");
        bw.newLine();
        bw.flush();
        String username = br.readLine();

        bw.write("Password:");
        bw.newLine();
        bw.flush();
        String password = br.readLine();

        // Validate the username and password.
        if (username != null && password != null && users.containsKey(username) && users.get(username).equals(password)) {
            currentUser = username;
            bw.write("Welcome " + username + "!");
            bw.newLine();
            bw.flush();
            return true;
        } else {
            bw.write("Invalid creds. Bye.");
            bw.newLine();
            bw.flush();
            return false;
        }
    }

    private static boolean signup(BufferedReader br, BufferedWriter bw) throws IOException {
        bw.write("New username:");
        bw.newLine();
        bw.flush();
        String newUsername = br.readLine();

        // Check if the username already exists.
        if (newUsername != null && users.containsKey(newUsername)) {
            bw.write("User exists. Bye.");
            bw.newLine();
            bw.flush();
            return false;
        }

        bw.write("New password:");
        bw.newLine();
        bw.flush();
        String newPassword = br.readLine();

        // Add the new username and password to the `users` map.
        if (newUsername != null && newPassword != null) {
            users.put(newUsername, newPassword);
            currentUser = newUsername;
            bw.write("Welcome " + newUsername + "!");
            bw.newLine();
            bw.flush();
            return true;
        } else {
            bw.write("Signup failed. Bye.");
            bw.newLine();
            bw.flush();
            return false;
        }
    }

    private static String calculate(String expr) {
        try {
            if (expr.contains("+")) {
                String[] parts = expr.split("\\+");
                if (parts.length != 2) return "Invalid format.";
                int a = Integer.parseInt(parts[0].trim());
                int b = Integer.parseInt(parts[1].trim());
                return "Result: " + (a + b);
            } else if (expr.contains("*")) {
                String[] parts = expr.split("\\*");
                if (parts.length != 2) return "Invalid format.";
                int a = Integer.parseInt(parts[0].trim());
                int b = Integer.parseInt(parts[1].trim());
                return "Result: " + (a * b);
            } else {
                return "Use + or *.";
            }
        } catch (NumberFormatException e) {
            return "Numbers only.";
        }
    }
}
