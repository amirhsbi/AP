#include <iostream>
#include <vector>
#include <fstream>
#include <iomanip>

using namespace std;

class Deposit {
protected:
    double initialInvestment;
    double inventory;
    int userId;

public:
    Deposit(double initialInvestment, int userId) : initialInvestment(initialInvestment), userId(userId) {
        inventory = initialInvestment;
    }

    double getInitialInvestment() const {
        return initialInvestment;
    }

    void setInitialInvestment(double initialInvestment) {
        Deposit::initialInvestment = initialInvestment;
    }

    int getUserId() const {
        return userId;
    }

    void setUserId(int userId) {
        Deposit::userId = userId;
    }

    double getInventory() const {
        return inventory;
    }

    void setInventory(double inventory) {
        Deposit::inventory = inventory;
    }
};

class ShortTermDeposit : public Deposit {
private:
    int id;

public:
    ShortTermDeposit(int id, double initialInvestment, int userId) : Deposit(initialInvestment, userId) {
        this->id = id;
    }

    int getId() const {
        return id;
    }

    void setId(int id) {
        ShortTermDeposit::id = id;
    }
};

class LongTermDeposit : public Deposit {
private:
    int shortTermDepositId;
    int years;
    int passedMonths;
public:
    LongTermDeposit(double initialInvestment, int userId, int shortTermDepositId, int years) : Deposit(
            initialInvestment, userId) {
        this->shortTermDepositId = shortTermDepositId;
        this->years = years;
        this->passedMonths = 0;
    }

    int getShortTermDepositId() const {
        return shortTermDepositId;
    }

    void setShortTermDepositId(int shortTermDepositId) {
        LongTermDeposit::shortTermDepositId = shortTermDepositId;
    }

    int getYears() const {
        return years;
    }

    void setYears(int years) {
        LongTermDeposit::years = years;
    }

    int getPassedMonths() const {
        return passedMonths;
    }

    void setPassedMonths(int passedMonths) {
        LongTermDeposit::passedMonths = passedMonths;
    }
};

class GharzolhasaneDeposit : public Deposit {
public:
    GharzolhasaneDeposit(double initialInvestment, int userid) : Deposit(initialInvestment, userid) {}
};

class User {
private:
    int id;
    double wallet;

public:
    User() {}

    User(int id, double wallet) {
        this->id = id;
        this->wallet = wallet;
    }

    int getId() const {
        return id;
    }

    void setId(int id) {
        User::id = id;
    }

    double getWallet() const {
        return wallet;
    }

    void setWallet(double wallet) {
        User::wallet = wallet;
    }
};

class Bank {
private:
    static int idCounter;
    int id;
    int shortTermProfitMargin;
    double shortTermMinimumInvestment;
    vector<ShortTermDeposit> shortTermDeposits;
    vector<LongTermDeposit> longTermDeposits;
    vector<GharzolhasaneDeposit> gharzolahsaneDeposits;

public:
    Bank() {}

    Bank(int id, int shortTermProfitMargin, double shortTermMinimumInvestment) {
        this->id = id;
        this->shortTermProfitMargin = shortTermProfitMargin;
        this->shortTermMinimumInvestment = shortTermMinimumInvestment;
    }

    int getId() const {
        return id;
    }

    void setId(int id) {
        Bank::id = id;
    }

    int getShortTermProfitMargin() const {
        return shortTermProfitMargin;
    }

    void setShortTermProfitMargin(int shortTermProfitMargin) {
        Bank::shortTermProfitMargin = shortTermProfitMargin;
    }

    double getShortTermMinimumInvestment() const {
        return shortTermMinimumInvestment;
    }

    void setShortTermMinimumInvestment(double shortTermMinimumInvestment) {
        Bank::shortTermMinimumInvestment = shortTermMinimumInvestment;
    }

    void createShortTermDeposit(int userId, double initialInvestment) {
        shortTermDeposits.push_back(ShortTermDeposit(idCounter++, initialInvestment, userId));
        cout << shortTermDeposits[shortTermDeposits.size() - 1].getId() << endl;
    }

    int searchShortTermDeposit(int shortTermDepositId) {
        for (int i = 0; i < shortTermDeposits.size(); i++) {
            if (shortTermDeposits[i].getId() == shortTermDepositId) {
                return i;
            }
        }
        return -1;
    }

    void createLongTermDeposit(int userId, int shortTermDepositId, int years, double initialInvestment) {
        int index = searchShortTermDeposit(shortTermDepositId);
        if (index == -1 || shortTermDeposits[index].getUserId() != userId) {
            cout << "Invalid short-term deposit" << endl;
        } else {
            longTermDeposits.push_back(LongTermDeposit(initialInvestment, userId, shortTermDepositId, years));
        }
    }

    void createGharzolhasaneDeposit(int userId, double initialInvestment) {
        gharzolahsaneDeposits.push_back(GharzolhasaneDeposit(initialInvestment, userId));
    }

    void updateDeposits(int months) {
        for (auto &shortTermDeposit: shortTermDeposits) {
            double profit = shortTermDeposit.getInitialInvestment() * months * shortTermProfitMargin / 100.0;
            shortTermDeposit.setInventory(shortTermDeposit.getInventory() + profit);
        }

        for (auto &longTermDeposit: longTermDeposits) {
            longTermDeposit.setPassedMonths(longTermDeposit.getPassedMonths() + months);
            if (longTermDeposit.getPassedMonths() / 12 >= longTermDeposit.getYears()) {
                longTermDeposit.setPassedMonths(
                        longTermDeposit.getPassedMonths() - longTermDeposit.getYears() * 12);
                double profit = longTermDeposit.getInitialInvestment() * longTermDeposit.getYears() * months *
                                shortTermProfitMargin / 100.0;
                longTermDeposit.setInventory(longTermDeposit.getInventory() + profit);
            }
        }
    }

    void reportShortTimeDeposit(int shortTermDepositId, int userId) {
        int index = searchShortTermDeposit(shortTermDepositId);
        if (index == -1 || shortTermDeposits[index].getUserId() != userId) {
            cout << "Invalid short-term deposit" << endl;
        } else {
            double inventory = shortTermDeposits[index].getInventory();
            for (auto &longTermDeposit: longTermDeposits) {
                if (longTermDeposit.getShortTermDepositId() == shortTermDepositId) {
                    inventory += longTermDeposit.getInventory() - longTermDeposit.getInitialInvestment();
                }
            }
            cout << setprecision(2) << fixed << inventory << endl;
        }
    }

    double calcAllMoney(int userId) {
        double money = 0;
        for (auto &shortTermDeposit: shortTermDeposits) {
            money += shortTermDeposit.getInventory();
        }
        for (auto &longTermDeposit: longTermDeposits) {
            money += longTermDeposit.getInventory();
        }
        return money;
    }
};

int Bank::idCounter = 1;


vector<Bank> readBanks(string fileName) {
    vector<Bank> banks;
    ifstream file(fileName);
    if (file.is_open()) {
        string line;
        for (int i = 0; getline(file, line); i++) {
            if (i != 0) {
                int index = line.find(',');

                int id = stoi(line.substr(0, index));
                line = line.substr(index + 1);

                index = line.find(',');

                int shortTermProfitMargin = stoi(line.substr(0, index));
                line = line.substr(index + 1);

                int shortTermMinimumInvestment = stoi(line);

                banks.push_back(Bank(id, shortTermProfitMargin, shortTermMinimumInvestment));
            }
        }
    }
    return banks;
}

vector<User> readUsers(string fileName) {
    vector<User> users;
    ifstream file(fileName);
    if (file.is_open()) {
        string line;
        for (int i = 0; getline(file, line); i++) {
            if (i != 0) {
                int index = line.find(',');

                int id = stoi(line.substr(0, index));
                line = line.substr(index + 1);

                double wallet = stof(line);

                users.push_back(User(id, wallet));
            }
        }
    }
    return users;
}

int searchBank(vector<Bank> banks, int id) {
    for (int i = 0; i < banks.size(); i++) {
        if (banks[i].getId() == id) {
            return i;
        }
    }
    return -1;
}


int searchUser(vector<User> users, int id) {
    for (int i = 0; i < users.size(); i++) {
        if (users[i].getId() == id) {
            return i;
        }
    }
    return -1;
}


int main(int argc, char *argv[]) {
    vector<string> args;
    string bankFile;
    string userFile;

    for (int i = 0; i < argc; i++) {
        args.push_back(argv[i]);
    }

    for (int i = 0; i < args.size(); i++) {
        if (args[i] == "-b") {
            bankFile = args[i + 1];
        }
        if (args[i] == "-u") {
            userFile = args[i + 1];
        }
    }


    vector<Bank> banks = readBanks(bankFile);
    vector<User> users = readUsers(userFile);

    while (true) {
        string command;
        cin >> command;

        if (command == "create_short_term_deposit") {
            int userId, bankId;
            double initialInvestment;
            cin >> userId >> bankId >> initialInvestment;
            int bankIndex = searchBank(banks, bankId);
            int userIndex = searchUser(users, userId);
            if (users[userIndex].getWallet() < initialInvestment ||
                initialInvestment < banks[bankIndex].getShortTermMinimumInvestment()) {
                cout << "Not enough money" << endl;
            } else {
                banks[bankIndex].createShortTermDeposit(userId, initialInvestment);
            }
        } else if (command == "create_long_term_deposit") {
            int userId, bankId, shortTermDepositId, years;
            double initialInvestment;
            cin >> userId >> bankId >> shortTermDepositId >> years >> initialInvestment;
            int bankIndex = searchBank(banks, bankId);
            int userIndex = searchUser(users, userId);
            if (users[userIndex].getWallet() < initialInvestment ||
                initialInvestment < years * banks[bankIndex].getShortTermMinimumInvestment()) {
                cout << "Not enough money" << endl;
            } else {
                banks[bankIndex].createLongTermDeposit(userId, shortTermDepositId, years, initialInvestment);
                cout << "OK" << endl;
            }
        } else if (command == "create_gharzolhasane_deposit") {
            int userId, bankId;
            double initialInvestment;
            cin >> userId >> bankId >> initialInvestment;
            int bankIndex = searchBank(banks, bankId);
            int userIndex = searchUser(users, userId);
            if (users[userIndex].getWallet() < initialInvestment) {
                cout << "Not enough money" << endl;
            } else {
                banks[bankIndex].createGharzolhasaneDeposit(userId, initialInvestment);
                cout << "OK" << endl;
            }
        } else if (command == "pass_time") {
            int months;
            cin >> months;
            for (auto &bank: banks) {
                bank.updateDeposits(months);
            }
            cout << "OK" << endl;
        } else if (command == "inventory_report") {
            int userId, bankId, shortTermDepositId;
            cin >> userId >> bankId >> shortTermDepositId;
            int bankIndex = searchBank(banks, bankId);
            banks[bankIndex].reportShortTimeDeposit(shortTermDepositId, userId);
        } else if (command == "calc_money_in_bank") {
            int userId, bankId;
            cin >> userId >> bankId;
            int bankIndex = searchBank(banks, bankId);
            cout << setprecision(2) << fixed << banks[bankIndex].calcAllMoney(userId) << endl;
        } else if (command == "calc_all_money") {
            int userId;
            cin >> userId;
            double allMoney = 0;
            for (auto &bank: banks) {
                allMoney += bank.calcAllMoney(userId);
            }
            cout << setprecision(2) << fixed << allMoney << endl;
        }
    }

    return 0;
}
