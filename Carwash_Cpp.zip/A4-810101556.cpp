﻿#include <iostream>
#include "CarWash.h"


CarWash::CarWash() {}

void CarWash::readStagesData(const string &filename)
{
    ifstream file(filename);
    if (!file.is_open())
    {
        cerr << "Error: Unable to open stages file " << filename << endl;
        return;
    }

    string line;
    bool headerSkipped = false;
    while (getline(file, line))
    {
        if (!headerSkipped)
        {
            headerSkipped = true;
            continue; // Skip header line
        }

        istringstream iss(line);
        int id, price;
        char delimiter;
        if (!(iss >> id >> delimiter >> price))
        {
            cerr << "Error: Invalid stages file format." << endl;
            break;
        }
        stages.emplace_back(id, price);
    }

    file.close();
}

void CarWash::readWorkersData(const string &filename)
{
    ifstream file(filename);
    if (!file.is_open())
    {
        cerr << "Error: Unable to open workers file " << filename << endl;
        return;
    }

    string line;
    bool headerSkipped = false;
    while (getline(file, line))
    {
        if (!headerSkipped)
        {
            headerSkipped = true;
            continue; // Skip header line
        }

        istringstream iss(line);
        int id, stageID, timeToFinish;
        char delimiter;
        if (!(iss >> id >> delimiter >> stageID >> delimiter >> timeToFinish))
        {
            cerr << "Error: Invalid workers file format." << endl;
            break;
        }
        workers.emplace_back(id, stageID, timeToFinish);
    }

    file.close();
}

void CarWash::passTime(int timeUnits)
{
    for (int i = 0; i < timeUnits; ++i)
    {
        // Increment time
        static int currentTime = 0;
        ++currentTime;

        // Report changes in car positions
        for (auto &car : cars)
        {
            if (car.getStatus() == "In line")
            {
                // Car in queue
                cout << currentTime << " Car " << car.getID() << ": Queue " << car.getPosition() << endl;
            }
            else if (car.getStatus() == "In service")
            {
                // Car in service
                cout << currentTime << " Car " << car.getID() << ": Stage " << car.getPosition() << " -> Done" << endl;
                car.setDone();
            }
        }
    }
}

void CarWash::carArrival(const vector<int> &stageIDs)
{
    static int nextCarID = 1;
    Car newCar(nextCarID++);

    // Add the car to the system
    cars.push_back(newCar);

    int currentTime = 0; // Replace this with actual current time
    cout << currentTime << " Car " << newCar.getID() << ": Arrived -> ";



    for (int stageID : stageIDs)
    {
        if (workers[stageID].getStatus() == "Idle") // از stageID به جای stageID - 1 استفاده شده است
        {
            workers[stageID].setWorking(newCar.getID());
            newCar.setInService(stageID + 1); // از stageID به جای stageID - 1 استفاده شده است
            cout << "Stage " << stageID + 1; // از stageID به جای stageID - 1 استفاده شده است
            break;
        }
        else if (stages[stageID].getNumCarsInQueue() < MAX_QUEUE_SIZE) // از stageID به جای stageID - 1 استفاده شده است
        {
            stages[stageID].addCarToQueue(newCar.getID());
            newCar.setInLine(stageID + 1); // از stageID به جای stageID - 1 استفاده شده است
            cout << "Queue " << stageID + 1; // از stageID به جای stageID - 1 استفاده شده است
            break;
        }
    }



    cout << endl;
}

void CarWash::getStageStatus(int stageID)
{
    if (stageID < 1 || stageID > stages.size())
    {
        cout << "NOT FOUND" << endl;
        return;
    }

    Stage &stage = stages[stageID - 1];
    cout << "Number of washed cars: " << stage.getNumCarsWashed() << endl;
    cout << "Number of cars in queue: " << stage.getNumCarsInQueue() << endl;
    cout << "Number of cars being washed: " << (workers[stageID - 1].getStatus() == "Idle" ? 0 : 1) << endl;
    cout << "Income: " << stage.getIncome() << endl;
}

void CarWash::getWorkerStatus(int workerID)
{
    if (workerID < 1 || workerID > workers.size())
    {
        cout << "NOT FOUND" << endl;
        return;
    }

    Worker &worker = workers[workerID - 1];
    if (worker.getStatus() == "Idle")
    {
        cout << "Idle" << endl;
    }
    else
    {
        cout << "Working: " << worker.getStatus() << endl;
    }
}

void CarWash::getCarStatus(int carID)
{
    bool found = false;
    for (const Car &car : cars)
    {
        if (car.getID() == carID)
        {
            found = true;
            cout << car.getStatus();
            if (car.getStatus() == "In line" || car.getStatus() == "In service")
            {
                cout << ": " << car.getPosition();
            }
            cout << endl;
            break;
        }
    }
    if (!found)
    {
        cout << "NOT FOUND" << endl;
    }
}
